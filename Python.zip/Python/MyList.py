mylist =[" Lahore", "Bahawalpur","Multan"]
#print(mylist)

# mylist.append("Karachi")
# print(mylist)
mylist.insert(2,"Karachi")
#print(mylist)


# print(MyNewList)
# print(MyNewList[3][0])
# print(MyNewList [0:3])

# Mutli Data Type List


MultiDataList=[ " String" ,5,True,["This Is A Sub List"],(1,3),{"Name":"Ali","Age":25}] 
#print(MultiDataList)
MyNewList= ["CS","IT","Ai",["Computer Science","PF","OOP","DSA"]]
MyNewList.remove("Ai")
#print(MyNewList)
MyNewList.pop(1)
# print(MyNewList)

MyUpdatedList= MyNewList.copy()
# print(MyUpdatedList)


NumbersList=[1,2,3,4,5,6,7,8,9]
# print(NumbersList)
# del NumbersList[0]
# print(NumbersList)
squares = [ x ** 2 for x in range(10) ]


print(squares)

